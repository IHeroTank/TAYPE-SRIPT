import { auth, db } from "./firebase-config.js";
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

document.getElementById('btn-entrar').addEventListener('click', async () => {
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    if (!email || !senha) return alert("Preencha e-mail e senha!");

    try {
        // 1. Tenta logar no Firebase Auth (verifica se a senha tá certa)
        const userCredential = await signInWithEmailAndPassword(auth, email, senha);
        const user = userCredential.user;

        // 2. Busca os dados desse usuário no Firestore para ver quem ele é
        const docRef = doc(db, "expositores", user.uid);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            const dados = docSnap.data();

            // CASO 1: É o ADMIN (Você)
            if (dados.role === "ADMIN") {
                alert("Bem-vindo, Admin! 👨‍🏫");
                window.location.href = "admin.html";
                return;
            }

            // CASO 2: É um ALUNO (Expositor)
            // Verifica se o campo 'isApproved' é verdadeiro
            if (dados.isApproved === true) {
                // Salva dados na sessão para usar depois
                localStorage.setItem("usuarioLogado", user.uid);
                localStorage.setItem("nomeBarraca", dados.nome);
                
                window.location.href = "produtos.html"; // Entra no sistema
            } else {
                // Se isApproved for false
                alert("⏳ Seu cadastro ainda está em ANÁLISE.\nAguarde o professor aprovar sua conta.");
                // Opcional: Deslogar ele para não ficar preso
                // auth.signOut();
            }

        } else {
            alert("Erro: Usuário autenticado, mas sem registro no banco de dados.");
        }

    } catch (erro) {
        console.error(erro);
        if (erro.code === 'auth/invalid-credential') {
            alert("E-mail ou senha incorretos.");
        } else {
            alert("Erro ao entrar: " + erro.message);
        }
    }
});