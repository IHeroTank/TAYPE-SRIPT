import { db } from "./firebase-config.js";
import { collection, getDocs, query, where } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const listaDiv = document.getElementById("lista-produtos");
const titulo = document.querySelector(".vitrine-titulo"); // Pega o título pra mudar o texto

// Função Principal: Carrega produtos (com ou sem filtro)
async function carregarProdutos(filtroVendedor = null) {
    listaDiv.innerHTML = "<p class='vitrine-loading'>Carregando...</p>";
    
    let q;
    // Se tiver filtro, busca só daquele vendedor. Se não, busca tudo.
    if (filtroVendedor) {
        q = query(collection(db, "produtos"), where("vendedor", "==", filtroVendedor));
        titulo.innerText = `Produtos de: ${filtroVendedor} (Clique aqui para ver todos)`;
        titulo.style.cursor = "pointer";
        titulo.onclick = () => carregarProdutos(); // Clicar no título limpa o filtro
    } else {
        q = collection(db, "produtos");
        titulo.innerText = "O que temos pra hoje?";
        titulo.style.cursor = "default";
        titulo.onclick = null;
    }

    const querySnapshot = await getDocs(q);
    listaDiv.innerHTML = "";

    if (querySnapshot.empty) {
        listaDiv.innerHTML = "<p>Nenhum produto encontrado.</p>";
        return;
    }

    querySnapshot.forEach((doc) => {
        const produto = doc.data();
        const id = doc.id;

        // Prepara o objeto para o carrinho
        const produtoString = JSON.stringify({ id, ...produto }).replace(/"/g, "&quot;");

        const cardHTML = `
            <div class="produto">
                <img src="${produto.imagem || 'https://via.placeholder.com/150'}" alt="${produto.nome}" class="produto-img">
                
                <h4>${produto.nome}</h4>
                <span class="preco">R$ ${produto.preco.toFixed(2)}</span>
                
                <span class="vendedor" style="cursor: pointer; color: #0d6efd; text-decoration: underline;" 
                      onclick="filtrarPor('${produto.vendedor}')" title="Ver apenas produtos desta barraca">
                    Barraca: <strong>${produto.vendedor || 'Desconhecido'}</strong>
                </span>

                <button onclick="adicionarAoCarrinho(${produtoString})">
                    Adicionar ao Carrinho 🛒
                </button>
            </div>
        `;
        listaDiv.innerHTML += cardHTML;
    });
}

// Torna a função de filtrar acessível no HTML
window.filtrarPor = function(nomeVendedor) {
    carregarProdutos(nomeVendedor);
};

// Função de adicionar ao carrinho (igual a antes)
window.adicionarAoCarrinho = function (produto) {
    let carrinho = JSON.parse(localStorage.getItem("carrinhoHackathon")) || [];
    carrinho.push(produto);
    localStorage.setItem("carrinhoHackathon", JSON.stringify(carrinho));
    alert(`"${produto.nome}" adicionado!`);
};

// Carrega tudo ao iniciar
carregarProdutos();