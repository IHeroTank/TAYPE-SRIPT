const carousel = document.getElementById("carousel");
const btnPrev = document.getElementById("btnPrev");
const btnNext = document.getElementById("btnNext");

const scrollAmount = 300;

btnNext.addEventListener("click", () => {
    carousel.scrollLeft += scrollAmount;
});

btnPrev.addEventListener("click", () => {
    carousel.scrollLeft -= scrollAmount;
});
