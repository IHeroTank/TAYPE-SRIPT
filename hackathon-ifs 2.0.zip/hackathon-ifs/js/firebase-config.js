import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyBSAEnOWd8v8yKJvvn_jnceDyHudx7SUb4",
  authDomain: "feira-ifs-final.firebaseapp.com",
  projectId: "feira-ifs-final",
  storageBucket: "feira-ifs-final.firebasestorage.app",
  messagingSenderId: "172634321578",
  appId: "1:172634321578:web:32927bfb7f80263d9516d3",
  measurementId: "G-H2FFQ9Q3LV"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export { db, auth };