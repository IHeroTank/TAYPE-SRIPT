import { db, auth } from "./firebase-config.js"; // Importa o auth que configuramos
import { createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { doc, setDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const form = document.getElementById('form-cadastro');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    // Pegar os valores dos campos
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const turma = document.getElementById('turma').value;
    const descricao = document.getElementById('descricao').value;

    try {
        // 1. Criar o usuário no Firebase Authentication
        const userCredential = await createUserWithEmailAndPassword(auth, email, senha);
        const user = userCredential.user;

        // 2. Criar o documento no Firestore com o MESMO ID (UID)
        await setDoc(doc(db, "expositores", user.uid), {
            nome: nome,
            email: email,
            turma: turma,
            descricao: descricao,
            role: "ALUNO",       // Define que é aluno
            isApproved: false,   // <--- Nasce BLOQUEADO
            criadoEm: new Date()
        });

        alert("Cadastro realizado! Aguarde a aprovação do Admin.");
        window.location.href = "login.html"; // Manda pro login

    } catch (erro) {
        console.error("Erro ao cadastrar:", erro);
        
        if (erro.code === 'auth/email-already-in-use') {
            alert("Esse e-mail já está cadastrado!");
        } else if (erro.code === 'auth/weak-password') {
            alert("A senha precisa ter pelo menos 6 caracteres.");
        } else {
            alert("Erro no cadastro: " + erro.message);
        }
    }
});