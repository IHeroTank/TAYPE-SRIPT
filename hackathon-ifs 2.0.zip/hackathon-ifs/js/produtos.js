import { db } from "./firebase-config.js";
import { collection, addDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// 1. VERIFICAÇÃO DE SEGURANÇA
const usuarioId = localStorage.getItem("usuarioLogado");
const usuarioNome = localStorage.getItem("nomeBarraca");

if (!usuarioId) {
    alert("Sessão expirada. Faça login novamente.");
    window.location.href = "login.html";
}

// 2. PREENCHER AUTOMATICAMENTE A TELA
// Preenche o nome da barraca na tela para o aluno conferir
document.getElementById('nomeBarracaDisplay').innerText = usuarioNome || "Expositor";
document.getElementById('nomeBarraca').value = usuarioNome || "";

const form = document.getElementById('form-produto');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    // Pegando os dados do formulário
    const nome = document.getElementById('nomeProduto').value;
    const preco = parseFloat(document.getElementById('preco').value);
    const estoque = parseInt(document.getElementById('estoque').value);
    const imagemUrl = document.getElementById('imagemProduto').value;
    
    // Se não tiver foto, usa uma padrão cinza
    const imagemFinal = imagemUrl ? imagemUrl : "https://via.placeholder.com/150";
  
    try {
        await addDoc(collection(db, "produtos"), {
            expositorId: usuarioId, // <--- PEGA AUTOMÁTICO DO LOCALSTORAGE
            vendedor: usuarioNome,  
            nome: nome,
            preco: preco,
            estoque: estoque,
            imagem: imagemFinal,
            criadoEm: new Date()
        });

        alert("Produto cadastrado com sucesso! 🚀");
        
        // Limpa os campos para o próximo
        document.getElementById('nomeProduto').value = "";
        document.getElementById('preco').value = "";
        document.getElementById('estoque').value = "";
        document.getElementById('imagemProduto').value = "";

    } catch (erro) {
        console.error("Erro: ", erro);
        alert("Erro ao salvar produto: " + erro.message);
    }
});