import { db } from "./firebase-config.js";
import { doc, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const lista = document.getElementById('lista-meus-pedidos');
const historicoIds = JSON.parse(localStorage.getItem("historicoPedidos")) || [];

async function carregarPedidos() {
    lista.innerHTML = "";

    if (historicoIds.length === 0) {
        lista.innerHTML = "<div class='alert'>Você ainda não fez pedidos.</div>";
        return;
    }

    for (const id of historicoIds.reverse()) {
        try {
            const docRef = doc(db, "pedidos", id);
            const docSnap = await getDoc(docRef);

            if (docSnap.exists()) {
                const pedido = docSnap.data();
                const data = pedido.data ? new Date(pedido.data.seconds * 1000).toLocaleString() : 'Recente';

                // Classes CSS personalizadas
                let classeStatus = "status-novo";
                if (pedido.status === "preparando") classeStatus = "status-preparando";
                if (pedido.status === "entregue") classeStatus = "status-entregue";
                if (pedido.status === "cancelado") classeStatus = "status-cancelado";

                let htmlBotao = "";
                if (pedido.status === "novo") {
                    htmlBotao = `<button class="btn-cancelar" onclick="cancelarPedido('${id}')">❌ Cancelar Pedido</button>`;
                }

                // HTML limpo sem Bootstrap
                lista.innerHTML += `
                    <div class="pedido-card">
                        <div class="pedido-header">
                            <span class="pedido-valor">R$ ${pedido.total.toFixed(2)}</span>
                            <span class="badge ${classeStatus}">${pedido.status}</span>
                        </div>
                        <p class="pedido-itens">${pedido.itens.map(i => i.nome).join(", ")}</p>
                        <small class="pedido-data">📅 ${data}</small>
                        ${htmlBotao}
                    </div>
                `;
            }
        } catch (e) {
            console.error("Erro", e);
        }
    }
}

window.cancelarPedido = async (id) => {
    if (!confirm("Tem certeza que deseja cancelar?")) return;
    try {
        await updateDoc(doc(db, "pedidos", id), { status: "cancelado" });
        alert("Pedido cancelado.");
        carregarPedidos();
    } catch (e) {
        alert("Erro: " + e.message);
    }
};

carregarPedidos();