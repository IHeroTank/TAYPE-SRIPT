import { db } from "./firebase-config.js";
import { collection, getDocs, doc, updateDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const listaPendentes = document.getElementById('lista-pendentes');
const listaAtivos = document.getElementById('lista-ativos');

async function carregarPaineis() {
    listaPendentes.innerHTML = "";
    listaAtivos.innerHTML = "";

    // Busca TODOS os expositores
    const querySnapshot = await getDocs(collection(db, "expositores"));

    let temPendentes = false;

    querySnapshot.forEach((documento) => {
        const dados = documento.data();
        const id = documento.id;

        // Ignora o próprio Admin para não aparecer na lista
        if (dados.role === "ADMIN") return;

        // Cria o HTML do item com CLASSE PERSONALIZADA
        const li = document.createElement('li');
        li.className = "item-admin";

        // LÓGICA: Verifica se isApproved é false (Pendente) ou true (Ativo)
        if (dados.isApproved === false) {
            temPendentes = true;

            // Layout Limpo sem Bootstrap
            li.innerHTML = `
                <div class="info-user">
                    <strong>${dados.nome}</strong> <br>
                    <small class="texto-secundario">${dados.email || 'Sem e-mail'}</small>
                </div>
                <button class="btn-acao btn-aprovar" onclick="aprovarUsuario('${id}')">Aprovar ✅</button>
            `;
            listaPendentes.appendChild(li);

        } else {
            // Layout Limpo sem Bootstrap
            li.innerHTML = `
                <div class="info-user">
                    <strong>${dados.nome}</strong> <br>
                    <small class="texto-secundario">ID: ${id.substring(0, 5)}...</small>
                </div>
                <button class="btn-acao btn-bloquear" onclick="bloquearUsuario('${id}')">Bloquear 🚫</button>
            `;
            listaAtivos.appendChild(li);
        }
    });

    if (!temPendentes) listaPendentes.innerHTML = "<p class='lista-vazia'>Nenhuma solicitação nova.</p>";
}

// Função para APROVAR (Muda isApproved para true)
window.aprovarUsuario = async function (id) {
    if (!confirm(`Confirma a aprovação deste aluno?`)) return;

    try {
        const ref = doc(db, "expositores", id);
        await updateDoc(ref, { isApproved: true });
        alert("Aluno aprovado! Agora ele pode acessar.");
        carregarPaineis(); // Recarrega a tela
    } catch (erro) {
        alert("Erro ao aprovar: " + erro.message);
        console.error(erro);
    }
};

// Função para BLOQUEAR (Muda isApproved para false)
window.bloquearUsuario = async function (id) {
    if (!confirm(`Deseja bloquear o acesso desta equipe?`)) return;

    try {
        const ref = doc(db, "expositores", id);
        await updateDoc(ref, { isApproved: false });
        alert("Acesso bloqueado.");
        carregarPaineis();
    } catch (erro) {
        alert("Erro ao bloquear.");
    }
};

carregarPaineis();