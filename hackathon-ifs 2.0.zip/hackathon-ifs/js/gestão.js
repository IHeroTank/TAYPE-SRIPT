import { db } from "./firebase-config.js";
import { collection, getDocs, orderBy, query, doc, updateDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// 1. SEGURANÇA: Verifica se o usuário está logado
const meuId = localStorage.getItem("usuarioLogado");
const meuNome = localStorage.getItem("nomeBarraca");

if (!meuId) {
    alert("Você precisa estar logado!");
    window.location.href = "login.html";
}

// Preenche o nome na tela
document.getElementById('nomeVendedorDisplay').innerText = meuNome;

// 2. FUNÇÃO QUE DESENHA OS BOTÕES DE STATUS (Layout Personalizado)
function gerarControleStatus(pedidoId, statusAtual) {
    const status = statusAtual || "novo";

    if (status === "novo") {
        return `
            <span class="badge bg-novo">Novo Pedido</span>
            <button class="btn btn-preparar" onclick="mudarStatus('${pedidoId}', 'preparando')">
                 Preparar / Separar
            </button>
        `;
    }
    else if (status === "preparando") {
        return `
            <span class="badge bg-andamento">Em Andamento...</span>
            <button class="btn btn-finalizar" onclick="mudarStatus('${pedidoId}', 'entregue')">
                 Finalizar / Entregar
            </button>
        `;
    }
    else if (status === "cancelado") {
        return `<span class="badge bg-cancel"> Cancelado pelo Cliente</span>`;
    }
    else {
        return `<span class="badge bg-fim">Concluído</span>`;
    }
}

// 3. FUNÇÃO QUE CARREGA OS PEDIDOS DO BANCO
async function carregarMeusPedidos() {
    const lista = document.getElementById('lista-pedidos');
    const totalVendasEl = document.getElementById('total-vendas');
    const qtdPedidosEl = document.getElementById('qtd-pedidos');

    lista.innerHTML = "<p class='loading'>Carregando vendas...</p>";

    // Busca TODOS os pedidos ordenados por data (do mais novo pro mais antigo)
    const q = query(collection(db, "pedidos"), orderBy("data", "desc"));
    const snapshot = await getDocs(q);

    let totalDinheiro = 0;
    let contadorPedidos = 0;
    lista.innerHTML = "";

    snapshot.forEach(docSnap => {
        const pedido = docSnap.data();
        const pedidoId = docSnap.id;

        // FILTRO: Verifica se NESSE pedido tem item MEU
        const meusItens = pedido.itens.filter(item => item.expositorId === meuId);

        if (meusItens.length > 0) {
            contadorPedidos++;

            const subtotalMeu = meusItens.reduce((acc, item) => acc + item.preco, 0);

            // Só soma no total financeiro se o pedido não estiver cancelado
            if (pedido.status !== 'cancelado') {
                totalDinheiro += subtotalMeu;
            }

            const resumoItens = meusItens.map(i => `${i.nome}`).join(", ");

            // Formata a data e hora
            const dataFormatada = pedido.data ? new Date(pedido.data.seconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recente';

            // Gera os botões corretos
            const botoesAcao = gerarControleStatus(pedidoId, pedido.status);

            // Gera o HTML do Card (Sem Bootstrap)
            const html = `
                <div class="pedido-item">
                    <div class="pedido-top">
                        <span class="preco-pedido">R$ ${subtotalMeu.toFixed(2)}</span>
                        <small class="hora-pedido"> ${dataFormatada}</small>
                    </div>
                    
                    <p class="detalhes-pedido">
                        Cliente: <strong>${pedido.clienteNome}</strong><br>
                        Itens: ${resumoItens}
                    </p>

                    <div class="area-acao">
                        ${botoesAcao}
                    </div>
                </div>
            `;
            lista.innerHTML += html;
        }
    });

    if (contadorPedidos === 0) {
        lista.innerHTML = "<div style='text-align:center; padding:20px; color:#666;'>Nenhuma venda encontrada ainda.</div>";
    }

    // Atualiza os contadores no topo da tela
    totalVendasEl.innerText = "R$ " + totalDinheiro.toFixed(2);
    qtdPedidosEl.innerText = contadorPedidos;
}

// 4. FUNÇÃO GLOBAL PARA MUDAR O STATUS (Acessível pelo HTML)
window.mudarStatus = async function (id, novoStatus) {
    // Texto de confirmação dinâmico
    let textoAcao = novoStatus === 'preparando' ? "iniciar a preparação/separação" : "finalizar este pedido";

    if (!confirm(`Deseja ${textoAcao}?`)) return;

    try {
        const docRef = doc(db, "pedidos", id);
        await updateDoc(docRef, {
            status: novoStatus
        });

        // Recarrega a lista para atualizar a cor do botão e o status
        carregarMeusPedidos();

    } catch (erro) {
        alert("Erro ao atualizar status: " + erro.message);
    }
};

// Inicializa a tela carregando os pedidos
carregarMeusPedidos();