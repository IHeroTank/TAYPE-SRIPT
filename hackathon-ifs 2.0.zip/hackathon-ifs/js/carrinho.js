import { db } from "./firebase-config.js";
import { collection, addDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const lista = document.getElementById('lista-itens');
const totalSpan = document.getElementById('valor-total');
const btnFinalizar = document.getElementById('btn-finalizar');

// 1. Carregar itens da memória
let carrinho = JSON.parse(localStorage.getItem('carrinhoHackathon')) || [];
let total = 0;

function desenharCarrinho() {
    lista.innerHTML = "";
    total = 0;

    if (carrinho.length === 0) {
        lista.innerHTML = "<p class='text-center'>Carrinho vazio </p>";
        return;
    }

    carrinho.forEach((item, index) => {
        total += item.preco;

        // HTML LIMPO SEM BOOTSTRAP
        lista.innerHTML += `
            <li class="item-carrinho">
                <span>${item.nome} <small style="color:#777">(${item.expositorId})</small></span>
                <span class="badge-preco">R$ ${item.preco.toFixed(2)}</span>
            </li>
        `;
    });

    totalSpan.innerText = "R$ " + total.toFixed(2);
}

desenharCarrinho();

// 2. Finalizar Compra
btnFinalizar.addEventListener('click', async () => {
    const cliente = document.getElementById('nomeCliente').value;

    if (!cliente || carrinho.length === 0) {
        alert("Preencha seu nome e adicione itens!");
        return;
    }

    try {
        // Criar o pedido no Firebase E PEGAR A REFERÊNCIA (docRef)
        const docRef = await addDoc(collection(db, "pedidos"), {
            clienteNome: cliente,
            itens: carrinho,
            total: total,
            status: "novo",
            data: new Date()
        });

        // --- NOVIDADE AQUI ---
        // Salva o ID do pedido no histórico local do navegador
        let meusPedidos = JSON.parse(localStorage.getItem("historicoPedidos")) || [];
        meusPedidos.push(docRef.id);
        localStorage.setItem("historicoPedidos", JSON.stringify(meusPedidos));
        // ---------------------

        alert("Pedido realizado! Vamos te levar para acompanhar o status.");
        localStorage.removeItem('carrinhoHackathon');

        // Agora manda ele para a página de acompanhamento, não mais para a vitrine
        window.location.href = "meus-pedidos.html";

    } catch (erro) {
        console.error("Erro:", erro);
        alert("Erro ao finalizar pedido.");
    }
});