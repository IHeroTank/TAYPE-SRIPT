const btnMenu = document.getElementById("btnMenu");
const menu = document.getElementById("menuLateral");
const overlay = document.getElementById("overlay");

function toggleMenu() {
    const aberto = menu.classList.toggle("ativo");
    overlay.classList.toggle("ativo");
    btnMenu.setAttribute("aria-expanded", aberto);
}

btnMenu.addEventListener("click", toggleMenu);
overlay.addEventListener("click", toggleMenu);
